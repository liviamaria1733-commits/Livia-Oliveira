# Portfólio Base

Projeto-base de portfólio para estudantes, feito só com **HTML, CSS e JavaScript**.
Não precisa instalar nada além do VS Code e da extensão Live Server.

O site tem menu responsivo (funciona no celular), tema claro e escuro, e as seções
**Sobre mim**, **Habilidades**, **Projetos**, **Formação** e **Contato**.

---

## Como rodar no VS Code

### 1. Baixe e extraia o projeto
1. Baixe o arquivo `portfolio-base.zip`.
2. Clique com o botão direito no arquivo e escolha **Extrair tudo** (Windows) ou dê dois cliques (Mac).
3. Guarde a pasta extraída em um lugar fácil de achar, como `Documentos`.

### 2. Abra a pasta no VS Code
1. Abra o VS Code.
2. Vá em **File > Open Folder** (Arquivo > Abrir Pasta).
3. Escolha a pasta `portfolio-base`, a que contém o `index.html`.

> Abra a **pasta**, não só o arquivo. Assim o Live Server encontra o CSS, o JavaScript e as imagens.

### 3. Instale o Live Server (só na primeira vez)
1. Clique no ícone de **Extensões** na barra lateral (ou aperte `Ctrl+Shift+X`).
2. Pesquise por **Live Server** (autor: Ritwick Dey).
3. Clique em **Install**.

O VS Code também vai sugerir essa extensão sozinho ao abrir a pasta.

### 4. Abra o site
1. No explorador de arquivos, clique com o botão direito em `index.html`.
2. Escolha **Open with Live Server**.
3. O navegador abre o site em `http://127.0.0.1:5500`.

Também dá para clicar em **Go Live**, no canto inferior direito do VS Code.

A cada vez que você salvar um arquivo (`Ctrl+S`), a página atualiza sozinha.
Para parar o servidor, clique em **Port: 5500** na barra inferior.

---

## Estrutura de arquivos

```
portfolio-base/
├── index.html          estrutura e textos da página
├── css/
│   └── style.css       cores, fontes e layout
├── js/
│   └── script.js       dados (habilidades, projetos) e interações
├── assets/
│   └── img/            fotos e imagens dos projetos
├── .vscode/
│   └── extensions.json recomenda o Live Server
└── README.md           este arquivo
```

---

## Como personalizar

Procure por comentários **TROQUE** no `index.html` e por **SEUS DADOS** no `js/script.js`.

| O que mudar | Onde |
|---|---|
| Seu nome, título da aba e descrição | `index.html` (`<title>`, logo do menu, `<h1>`, rodapé) |
| Texto de "Sobre mim" | `index.html`, seção `#sobre` |
| Sua foto | Coloque a imagem em `assets/img/` e troque o `src` em `index.html` |
| Habilidades e níveis | `js/script.js`, array `HABILIDADES` |
| Projetos (título, texto, links, imagem) | `js/script.js`, array `PROJETOS` |
| Formação | `index.html`, seção `#formacao` (cada item é um `<li>`) |
| E-mail, GitHub e LinkedIn | `index.html` (seção `#contato`) e `EMAIL_CONTATO` em `js/script.js` |
| Cores do site | `css/style.css`, variáveis no início do arquivo (`:root`) |
| Fontes | Link do Google Fonts no `<head>` e variáveis `--fonte-titulo` e `--fonte-texto` |

### Adicionar um projeto
Copie um bloco `{ ... }` dentro de `PROJETOS` em `js/script.js`, cole logo abaixo (com uma vírgula entre os blocos) e mude os textos.
Se o projeto não tiver demonstração online, deixe `demo: ""` e o botão **Ver projeto** não aparece.

### Adicionar uma seção ao menu
1. Crie a seção em `index.html` com um `id`, por exemplo `<section class="secao" id="certificados">`.
2. Adicione `<li><a href="#certificados">Certificados</a></li>` dentro do `<nav>`.

---

## Problemas comuns

**A página abre sem estilo ou sem imagens.**
Você provavelmente abriu só o arquivo, e não a pasta. Feche o VS Code e use **File > Open Folder** na pasta `portfolio-base`.

**Não aparece "Open with Live Server".**
A extensão não está instalada ou o VS Code precisa ser reiniciado. Instale o Live Server e reabra o VS Code.

**As habilidades e os projetos não aparecem.**
Há um erro no `js/script.js`, geralmente uma vírgula ou aspas faltando. Abra o navegador, aperte `F12`, vá na aba **Console** e leia a mensagem de erro.

**As fontes estão diferentes.**
As fontes vêm da internet. Sem conexão, o navegador usa uma fonte padrão e o site continua funcionando.

**O formulário não envia a mensagem sozinho.**
Este projeto não tem servidor. O botão abre o programa de e-mail do visitante com a mensagem pronta. Para receber mensagens sem isso, use um serviço de formulários, como o Formspree.

---

## Publicar na internet (opcional)

1. Crie um repositório no GitHub e envie os arquivos do projeto.
2. No repositório, abra **Settings > Pages**.
3. Em **Branch**, escolha `main` e a pasta `/ (root)`, e clique em **Save**.
4. Depois de alguns minutos, o site fica disponível em `https://seu-usuario.github.io/nome-do-repositorio`.

---

## Ideias para evoluir o portfólio

- Troque as cores e as fontes para combinar com seu estilo.
- Adicione uma seção de certificados ou de depoimentos.
- Coloque capturas de tela reais nos seus projetos.
- Crie uma versão do currículo em PDF e adicione um botão de download.
