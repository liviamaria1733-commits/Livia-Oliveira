/* =========================================================
   PORTFÓLIO BASE: JAVASCRIPT
   Na parte 1 estão os DADOS que você deve editar.
   Da parte 2 em diante é o código que faz o site funcionar.
   ========================================================= */

/* ---------- 1. SEUS DADOS (edite aqui) ---------- */

// E-mail que receberá as mensagens do formulário de contato
const EMAIL_CONTATO = "seuemail@exemplo.com";

// Habilidades: nivel vai de 0 a 100
const HABILIDADES = [
  { nome: "HTML",        nivel: 80 },
  { nome: "CSS",         nivel: 70 },
  { nome: "JavaScript",  nivel: 50 },
  { nome: "Git e GitHub", nivel: 40 },
  { nome: "Lógica de programação", nivel: 65 },
  { nome: "Trabalho em equipe",    nivel: 85 }
];

// Projetos: copie e cole um bloco { ... } para adicionar outro.
// Se não tiver link, deixe "" (texto vazio) e o botão não aparece.
const PROJETOS = [
  {
    titulo: "Nome do projeto 1",
    descricao: "Explique em uma ou duas frases o que o projeto faz e qual problema ele resolve.",
    tecnologias: ["HTML", "CSS"],
    imagem: "assets/img/projeto.svg",
    demo: "",
    codigo: "https://github.com/seu-usuario/projeto-1"
  },
  {
    titulo: "Nome do projeto 2",
    descricao: "Conte o que você aprendeu ao fazer este projeto.",
    tecnologias: ["HTML", "CSS", "JavaScript"],
    imagem: "assets/img/projeto.svg",
    demo: "https://seu-usuario.github.io/projeto-2",
    codigo: "https://github.com/seu-usuario/projeto-2"
  },
  {
    titulo: "Nome do projeto 3",
    descricao: "Projeto em grupo, trabalho da escola ou desafio de um curso.",
    tecnologias: ["JavaScript"],
    imagem: "assets/img/projeto.svg",
    demo: "",
    codigo: "https://github.com/seu-usuario/projeto-3"
  }
];

/* ---------- 2. Habilidades: monta a lista na tela ---------- */
function montarHabilidades() {
  const lista = document.getElementById("lista-habilidades");

  HABILIDADES.forEach(function (item) {
    const li = document.createElement("li");
    li.className = "habilidade";

    const topo = document.createElement("div");
    topo.className = "habilidade__topo";

    const nome = document.createElement("span");
    nome.textContent = item.nome;

    const valor = document.createElement("span");
    valor.className = "habilidade__valor";
    valor.textContent = item.nivel + "%";

    topo.append(nome, valor);

    const barra = document.createElement("div");
    barra.className = "habilidade__barra";
    barra.setAttribute("role", "img");
    barra.setAttribute("aria-label", item.nome + ": " + item.nivel + "%");

    const preenchimento = document.createElement("span");
    preenchimento.style.width = item.nivel + "%";
    barra.append(preenchimento);

    li.append(topo, barra);
    lista.append(li);
  });
}

/* ---------- 3. Projetos: monta os cartões na tela ---------- */
function criarLink(texto, url) {
  const a = document.createElement("a");
  a.href = url;
  a.textContent = texto;
  a.target = "_blank";
  a.rel = "noopener";
  return a;
}

function montarProjetos() {
  const area = document.getElementById("lista-projetos");

  PROJETOS.forEach(function (projeto) {
    const cartao = document.createElement("article");
    cartao.className = "projeto";

    const img = document.createElement("img");
    img.src = projeto.imagem;
    img.alt = "Imagem do projeto " + projeto.titulo;
    img.loading = "lazy";

    const corpo = document.createElement("div");
    corpo.className = "projeto__corpo";

    const titulo = document.createElement("h3");
    titulo.textContent = projeto.titulo;

    const descricao = document.createElement("p");
    descricao.textContent = projeto.descricao;

    const tags = document.createElement("ul");
    tags.className = "projeto__tags";
    projeto.tecnologias.forEach(function (tec) {
      const li = document.createElement("li");
      li.textContent = tec;
      tags.append(li);
    });

    const links = document.createElement("div");
    links.className = "projeto__links";
    if (projeto.demo)   links.append(criarLink("Ver projeto", projeto.demo));
    if (projeto.codigo) links.append(criarLink("Código", projeto.codigo));

    corpo.append(titulo, descricao, tags, links);
    cartao.append(img, corpo);
    area.append(cartao);
  });
}

/* ---------- 4. Menu do celular (abrir e fechar) ---------- */
function configurarMenu() {
  const botao = document.getElementById("botao-menu");
  const menu = document.getElementById("menu");

  function definirMenu(aberto) {
    menu.classList.toggle("aberto", aberto);
    botao.setAttribute("aria-expanded", String(aberto));
    botao.setAttribute("aria-label", aberto ? "Fechar menu" : "Abrir menu");
  }

  botao.addEventListener("click", function () {
    definirMenu(!menu.classList.contains("aberto"));
  });

  // Fecha ao clicar em um link do menu
  menu.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () { definirMenu(false); });
  });

  // Fecha com a tecla Esc
  document.addEventListener("keydown", function (evento) {
    if (evento.key === "Escape") definirMenu(false);
  });
}

/* ---------- 5. Destaca no menu a seção que está na tela ---------- */
function configurarLinkAtivo() {
  const links = document.querySelectorAll(".menu a[href^='#']");
  const secoes = document.querySelectorAll("main section[id]");

  const observador = new IntersectionObserver(function (entradas) {
    entradas.forEach(function (entrada) {
      if (!entrada.isIntersecting) return;
      links.forEach(function (link) {
        link.classList.toggle("ativo", link.getAttribute("href") === "#" + entrada.target.id);
      });
    });
  }, { rootMargin: "-45% 0px -50% 0px" });

  secoes.forEach(function (secao) { observador.observe(secao); });
}

/* ---------- 6. Tema claro / escuro ---------- */
function configurarTema() {
  const botao = document.getElementById("botao-tema");
  const raiz = document.documentElement;

  let salvo = null;
  try { salvo = localStorage.getItem("tema"); } catch (e) { /* ignora */ }

  const preferePreto = window.matchMedia("(prefers-color-scheme: dark)").matches;
  raiz.setAttribute("data-theme", salvo || (preferePreto ? "dark" : "light"));

  botao.addEventListener("click", function () {
    const novo = raiz.getAttribute("data-theme") === "dark" ? "light" : "dark";
    raiz.setAttribute("data-theme", novo);
    try { localStorage.setItem("tema", novo); } catch (e) { /* ignora */ }
  });
}

/* ---------- 7. Formulário de contato ----------
   Este site não tem servidor. Ao enviar, o formulário abre o programa
   de e-mail do visitante com a mensagem pronta para enviar. */
function configurarFormulario() {
  const form = document.getElementById("formulario");
  const status = document.getElementById("status-formulario");

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();
    status.className = "formulario__status";

    const campos = form.querySelectorAll("input, textarea");
    let primeiroInvalido = null;

    campos.forEach(function (campo) {
      const valido = campo.checkValidity() && campo.value.trim() !== "";
      campo.classList.toggle("invalido", !valido);
      if (!valido && !primeiroInvalido) primeiroInvalido = campo;
    });

    if (primeiroInvalido) {
      status.textContent = "Preencha todos os campos com um e-mail válido.";
      status.classList.add("erro");
      primeiroInvalido.focus();
      return;
    }

    const nome = form.nome.value.trim();
    const email = form.email.value.trim();
    const mensagem = form.mensagem.value.trim();

    const assunto = "Contato pelo portfólio: " + nome;
    const corpo = mensagem + "\n\n" + nome + "\n" + email;

    window.location.href =
      "mailto:" + EMAIL_CONTATO +
      "?subject=" + encodeURIComponent(assunto) +
      "&body=" + encodeURIComponent(corpo);

    status.textContent = "Abrindo seu programa de e-mail para enviar a mensagem.";
    form.reset();
  });
}

/* ---------- 8. Ano no rodapé ---------- */
function atualizarAno() {
  document.getElementById("ano").textContent = new Date().getFullYear();
}

/* ---------- 9. Inicialização ---------- */
configurarTema();
montarHabilidades();
montarProjetos();
configurarMenu();
configurarLinkAtivo();
configurarFormulario();
atualizarAno();
